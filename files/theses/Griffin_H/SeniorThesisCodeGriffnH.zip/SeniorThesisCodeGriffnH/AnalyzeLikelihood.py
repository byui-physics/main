"""
"AnalyzeLikelihood.py"
Last update: 10/28/2020
Creator: Hadassah B Griffin
Contact: hadassahbmeyer@gmail.com

Program purpose: Create the following types of plots:
1. Cost profile for a single parameter
2. Internal parameter relationship for fixed parameter and another
   in the model.
3. Plot two different profile likelihoods that exist in seperate files.
"""

def main():
    import numpy as np
    import pylab
    import matplotlib.pyplot as plt
    import os
    import sys

    #must be different for each respective model---put parameters on on line
    paramLabels = [r"$hw$",
                   r"$h_1$",
                   r"$c_1$",
                   r"$c_2$",
                   r"$\rho_1$",
                   r"$\rho_2$", #9 and higher model dimensions---no ratio 
                   #r"$\rho_2 / \rho_{hsp}$",#ratio for 8 parameter versionn  
                   r"$\alpha_1$",
                   r"$\alpha_2$",
                   r"$c_{hsp}$",
                   r"$\rho_{hsp}$",
                   r"$\alpha_{hsp}$"
    ]
    
    #details to call saved file: parameter, environment type, frequency, save path
    #-----Parameters to modify for each run----#
    N = 10  #parameter number (x-axis), fixed parameter
    N_y = 6 #optional parameter to plot on y-axis, instead of cost
    file_type = "gravel_iso"
    frequency = 100
    left_bound = -5
    right_bound = 5
    layer_thickness = 35

    #file name options and info----this is very important to change,
    #based on what package used.
    #the file_plot_path must mirror the data path in name, with the exception
    #of "plots" being
    #added on the end; plot title also is useful for distinguishing plots
    
    file_data_path = "data/likelihood_11_Params_simplex/env_gravel/"
    file_data_path_compare = "data/fixed_LH_cost/" 
    file_plot_path = "plots/likelihood_10_Params_plots/"
        
    model_plot_title = "11 Params 100 Hz Gravel"
    yaxis_cost_save_name = "cost"
    yaxis_N_y_save_name = str(N_y)
    yaxis_type = ""
    centered_data_save_ex = ""
    
    #option to save; option to do cost or other parameter on y-axis and such
    savePlots = False
    yaxisCost = False
    yaxisN_y = True
    centerData = True
    compareDifferentOptimizations = True #option to compare two different files
    #----------------------------------------------#     

    proxyLeftB = str(left_bound)
    proxyRightB = str(right_bound)
    proxyFrequency = str(frequency)
    
    decimalCheckLB = proxyLeftB.find('.')
    decimalCheckRB = proxyRightB.find('.')
    decimalCheckFrequency = proxyFrequency.find('.')
    
    if decimalCheckLB != -1:
        proxyLeftB = proxyLeftB.replace('.','o')
    if decimalCheckRB != -1:
        proxyRightB = proxyRightB.replace('.','o')
    if decimalCheckFrequency != -1:
        proxyFrequency = proxyFrequency.replace('.','o')
    
    #file name assembled---extension to where it is saved is contained in
    #file_data_path variable
    
    data_file_name = "{6}Env_{0}_{1}_{2}m_l{3}_r{4}_{5}.npy".format(file_type,
                                                                    proxyFrequency, layer_thickness, proxyLeftB, proxyRightB, N, file_data_path)

    if compareDifferentOptimizations == True:
        data_file_name_compare = "{6}Env_{0}_{1}_{2}m_l{3}_r{4}_{5}.npy".format(
            file_type, proxyFrequency, layer_thickness, proxyLeftB, proxyRightB,
            N, file_data_path_compare)
            

    print("Searching for data file named ", data_file_name)
    #see if data file path exists. If not, exit the program
    data_file_exists_check = True
    data_file_exists_check = os.path.exists(data_file_name)

    if compareDifferentOptimizations == True:
        data_file_compare_exists_check = True
        data_file_compare_exists_check = os.path.exists(data_file_name_compare)

        if data_file_compare_exists_check == False:
            print("Warning: data file name for comparison not found; check name of file being called for. Exitting program.")
            print("File name searched for: ", data_file_name_compare)
            sys.exit()
        else:
            print("Preparing to load comparable data...")
            data_compare = np.load(data_file_name_compare)
        
    if data_file_exists_check == False:
        print("Warning: data file name not found; check name of file being called for. Exitting program.")
    else:
        print("Preparing to load data...")
        data = np.load(data_file_name)

        #prevent plotting data from doing two options
        if yaxisCost == True  and  yaxisN_y == True:
            print("Error: two y-axis options saved as true. Defaulting to yaxis save option.")
            yaxisCost = True
            yaxisN_y = False
            yaxisN_y_all = False

         #center the data; the index minimum cost, 0, is where the values
         #are at their default
        if centerData == True:
            i = np.argmin(data[:,-1])
            PDefault = data[i, N]

        
        # Plots cost vs. parameter N
        if yaxisCost == True:

            #shifts the center (original value has loest cost. Find entry with with lowest cost.
            if centerData == True:
                pylab.plot(data[:,N]- PDefault, data[:,-1])
                centered_data_save_ex = "_centered"
                print("Centered option is on.")

                if compareDifferentOptimizations == True:
                    pylab.plot(data_compare[:,N]- PDefault, data_compare[:,-1])
                    print("Centered option is on for compare data, too.")

            else:
                pylab.plot(data[:,N], data[:,-1])
                print("Centered option is off.")

                if compareDifferentOptimizations == True:
                    pylab.plot(data_compare[:,N], data_compare[:,-1])
                    print("Centered option is off for compare, too.")

            #plt.semilogy() #option for log plot
            plt.ylabel("Cost")
            paramX = paramLabels[N]
            plt.xlabel(paramX)
            plt.title("{5} {0} LH Profile for {1} {2} Hz; LB_{3} RB_{4} vs. Cost".format(file_type, paramX, proxyFrequency, proxyLeftB, proxyRightB,                                                                model_plot_title))

            if compareDifferentOptimizations == True:
                plt.legend(["Blue = {0}".format(file_data_path),
                            "Orange = {0}".format(file_data_path_compare)])

            #set save extension

            yaxis_type = yaxis_cost_save_name


        if yaxisN_y == True:
            if centerData == True:
                pylab.plot(data[:,N]- PDefault, data[:,N_y])
                centered_data_save_ex = "_centered"
                print("Centered option is on.")

                if compareDifferentOptimizations == True:
                    pylab.plot(data_compare[:,N]- PDefault, data_compare[:,N_y])

            else:
                pylab.plot(data[:,N], data[:,N_y])
                print("Centered option is off.")

                if compareDifferentOptimizations == True:
                    pylab.plot(data_compare[:,N], data_compare[:,N_y])

            paramX = paramLabels[N]
            paramY = paramLabels[N_y]
            plt.xlabel(paramX)
            plt.ylabel(paramY)
            plt.title("{6} {0} LH {2}Hz LB_{3} RB_{4}".format(file_type, paramX, frequency, left_bound, proxyRightB, paramY, model_plot_title))

            if compareDifferentOptimizations == True:
                plt.legend(["Blue = {0}".format(file_data_path), "Orange = {0}".format(file_data_path_compare)])

            #set save extension type
            yaxis_type = yaxis_N_y_save_name

        pylab.show()

        #save plots if savePlots condition above set to true and save path
        #specified
        
        if savePlots == True:
            print("Saving plot with y-axis "+yaxis_type)

            plotSaveName = "{3}Env_{0}_{1}_{8}m_{10}_l{4}_r{5}_P{2}_vs_P{6}{7}".format(file_type, proxyFrequency, N, file_plot_path, proxyLeftB, proxyRightB,
                        yaxis_type, centered_data_save_ex, layer_thickness)

            
            plt.savefig(plotSaveName)
            print("Saved as ", plotSaveName)
        
if __name__ == "__main__":
    main()

