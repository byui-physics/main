
"""
-Last program update: July 20, 2020
-Program: Calculate_Likelihood_Simplex.py
-Creator: Hadassah B. Griffin
-Contact information: hadassahbmeyer@gmail.com
-Purpose of program: Calculate likelihood profiles of a specific ORCA 
    environment. These
    likelihood profiles will help to identify how to remove sloppy parameters 
    from models
    based on each paramters cost function and relation to one another. 
    Unlike "Calculate_Likelihood.py",
    this program uses a likelihood package that uses the simplex method to 
    optimize instead of the Levenberg-Marquardt algorithim.
-Independant variables: environment type, sediment layer thickness, frequency, 
    parameter bounds
    left and right, parameter to fix while rest of paramters are "moved", 
    environment model
-Required packages: likelihood_simplexMethod (put in directory within the 
    current likelihoodfolder), 
    ORCA from orca_interface, Environments for required model
-Related programs: 
    Data analysis programs to process output of this program:
    - "AnalyzeLikelihood.py": basic, single likelihood profile graphs
    - "AnalyzeLikelihoodMultiple.py": plot multiple likelihood profiles at once
    - "AnalyzeLikelihoodCluster.py".: plot certain paramters with respect 
      to each other
    - "Plot_Cost_Contour.py": superimpose the likelihood data on a cost 
      contour plot
-Program Instructions:
    1. Make sure that the appropiate "Environments" file is selected, based on 
       the model being
       plotted for likelihood. Once selected, change the "file_data_path" 
       variable to the name
       of the folder where the ".npy" data files will be saved. 
    2. Go to the "Parameters to modify for each run" section. Adjust the 
       environment type, layer
       thickness, frequency, parameter to fix, left and right bounds 
       for moving this parameter,
       and the file data path. Save the program.
    3. Execute program in python shell or as a background job. An array will 
       be printed for each data run
       that presents the values of the parameters as the set parameter 
       increments by (0.1 increments by default). You can
       watch its progress by identifying the "N"th element in each 
        array produce. The last value of the
       array is the cost.
    4. If an "nmode" error occurs, it is because the bounds set have gone too 
        far and ORCA cannot find
       and nmode and create a transmission loss map. Look at the last value of 
        the "Nth" parameter,
       determine if it was incrementing up or down, and adjust the left or 
       right boundaries
       accordingly so that the last value printed of the N element becomes 
       the new bound. That way,
       the program will not go beyond that step.
    5. Data succesfully run will be saved in the data file directed by the 
       program. To analyze it,
       go to the appropiate data analysis file (see above related files to 
       program). When calling
       on the data file, adjust the bounds, environment, file save path, 
       frequency, parameter, or
       whatever file name information is needed to be called in that 
        program's "Parameters to modify 
       each run" section/places to call the data file. Do other adjustments 
       the analysis program 
       requires as necessarry.
    6. Run more data files as needed. 

"""
def main():

    import sys
    import numpy as np
    sys.path.append("likelihood/")
    import likelihood_simplexMethod
    import likelihood
    import time
    import matplotlib as plt
    import os
    from orca_interface import ORCA
    sys.path.append("./")
    from Environments import Environment
    print("Using package \"Environments\" ") 
    import pdb


    #Keep track of time; flag to stop data run if data path does not exist
    start = time.time() #current time in seconds since some time in the 1970s
    stopCalculation = False

    #Constants required for ORCA calculation
    zmin = 10
    zmax = 74
    zstep = 1
    zr = np.linspace(zmin, zmax, 256)
    r = [9]

    #Create likelihood profile of desired frequency, environment, paramter,
    #layer thickness, and bounds
    #bounds used for likelihood calculations: they will be how far the xtrue
    #goes down from its base value
    
    #-----Parameters to modify for each run----#
    load_calculated_best_fit = False #default: false
    new_best_fit_directory = "data/calculated_best_fits/"
    number_of_parameters = 11 #needed to call the loaded best fit
    file_type = "gravel_iso"
    N = 10  #parameter number
    layer_thickness = 35
    frequency = 100
    left_bound = -5
    right_bound = 5
    sampling_rate = 1e-1 #base: 0.1; step sizes determine sampling rate
                          #of likelihood profile
    file_data_path = "data/likelihood_11_params_simplex/env_gravel/" 

    #Environment package: if needed to be changed based on the model, go above
    #to where packages called into file
    #--------------------------#

    
    #file extensions
    #locates toml files
    file_path = "./svp_toml/iso_{0}m/".format(layer_thickness)
    
    #check if file extensions exist
    file_path_check = os.path.isdir(file_path)
    file_data_path_check = os.path.isdir(file_data_path)
    if file_path_check == False:
        print("Warning: toml directory file does not exist. Exiting program.")
    if file_data_path_check == False:
        print("Warning: file data path does not currently exist. Likelihood profile will not be calculated because a place is not set to save it.")
        stopCalculation = True     

    #change format of frequency if there is a decimal place so that there is
    #not a format saving error
    proxyFrequency = str(frequency)
    decimalCheckFrequency = proxyFrequency.find('.')
    proxyLeftB = str(left_bound)
    proxyRightB = str(right_bound)
    decimalCheckLB = proxyLeftB.find('.')
    decimalCheckRB = proxyRightB.find('.')
    
    if decimalCheckFrequency != -1:
        proxyFrequency = proxyFrequency.replace('.','o')
    if decimalCheckLB != -1:
        proxyLeftB = proxyLeftB.replace('.','o')
    if decimalCheckRB != -1:
        proxyRightB = proxyRightB.replace('.','o')
    

    if load_calculated_best_fit == True:
        
         #check if directory exists:
        NBF_load_name = "{0}best_fit_params_{1}_model_{2}_{3}Hz_{4}m.txt".format(
            new_best_fit_directory, number_of_parameters, file_type,
            proxyFrequency, layer_thickness)
        print("New best fit parameter data will be loaded from ", NBF_load_name)

        NBF_file_check = os.path.exists(NBF_load_name)

        if NBF_file_check == True:
            print("Calcualted new best fit values will be used for the initial parameter values.")
        else:
            print("File not found for calculated new best fit values. Using default values for parameters given by model.")

    #file name assembled
    
    final_file_name = "Env_{0}_{1}_{2}m_l{3}_r{4}".format(file_type, proxyFrequency, layer_thickness, proxyLeftB, proxyRightB)
    print("File will be saved as {} in directory {}".format(final_file_name, file_data_path))
    print("Calling svp toml files from ", file_path)
    
    #Create environment and its information based on given data
    env = Environment(file_path, file_type, frequency, zr, r, rmin = 1.5)
    env.orca.opt.iikpl = 2  # originally 1
    env.orca.opt.db_cut = 120
    env.orca.opt.phfac = 8

    #Create xtrue values: they are the initial values for all parameters

    #set xtrue according to user input
    if load_calculated_best_fit == True:
        if NBF_file_check == True:
            print("Loading calculated best fit...")
            xtrue = np.loadtxt(NBF_load_name)
        else:
            print("Using default model parameter values...")
            xtrue = env.x_current()
    else:
        print("Using default model parameter values...")
        xtrue = env.x_current()
    
    y0 = env.y(xtrue) #The "true" values---true data values
    

    print("xtrue: ", xtrue)

    if stopCalculation == False:
        #Calculate the likelihood profile; if adding scipy kwargss,
        #add them in the arguments here

        likelihood_simplexMethod.likelihood(env.y, xtrue, N,
                                            bound = [left_bound, right_bound],
                                            dt = sampling_rate,
                                            true_values = y0, std_values = 1,
                                            fixed_initial_guess = xtrue,
                                            export_result = True,
                                            extra_identifiers = file_data_path+final_file_name)
        
    else:
        print("Likelihood profile calculation not done.")

    end = time.time()
    print("Total run time: ")
    print(end - start)
    

    
if __name__ == "__main__":
    main()
