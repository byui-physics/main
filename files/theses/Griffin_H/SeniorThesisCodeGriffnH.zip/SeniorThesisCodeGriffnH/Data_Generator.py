"""
7/9/2020

-Program: Data_Generator_11_Param_Model.py

-Creator: Hadassah B. Meyer; hadassahbmeyer@gmail.com

-Purpose: generate the data/"ytrue" values for the 11 parameter ORCA 
  transmission loss model; save the data
          so it can be called by Fits.py to compare the cost of the 
          11 parameter model to lower parameter
          models. Also generate the x parameter values for 
          Find_New_Best_Fits.py.

-Important Notes: make sure that the same ORCA set up variables are used in 
 the generated model and the
 Fits.py model that is being compared. If you are changing more variables 
 than what are noted in the save name, it is reccomended that you create 
 different files to avoid overwriting data
 or that you adapt the save convention to your own needs.
"""
import os
import sys
sys.path.append("./") # current folder
import numpy as np
#from scipy.optimize import leastsq, fmin
from orca_interface import ORCA
from Environments import Environment
import time
from ProxyNameConverter import ProxyNameConverter #makes name saving easier

################################################################################
#Set up time
################################################################################
start = time.time()


################################################################################
# Setting up environment
################################################################################
#make sure these environmental variables are set the same as Fits.py
zmin = 10
zmax = 74
zstep = 1
# zr = np.arange(zmin, zmax + zstep, zstep)
zr = np.linspace(zmin, zmax, 256)
r = [9]

frequency = 100
file_type = "mud_iso"
layer_thickness = 35
file_path = "./svp_toml/iso_{0}m/".format(layer_thickness) #locates toml files
data_save_path = "data/data_ytrue_11_Params/"
param_values_save_path = "data/param_values_11_Params/"

env = Environment(file_path, file_type, frequency, zr, r, rmin = 1.5)

################################################################################
# Done
################################################################################


################################################################################
# Setting up fitting problem; generating the ytrue/data of the model
################################################################################
#noise_scalar = 0
x = env.x_current()
param_values = x
ytrue11 = env.y(x) #11 parameter set up
print("Calculated param values: ", param_values)
print("Calculated ytrue11: ", ytrue11)

################################################################################
#Saving the data
################################################################################

#create save name

#ready save name in case there are decimals in the values
#instantiate ProxyNameConverter.py instance
proxyConv = ProxyNameConverter(file_type) #dummy variable to initiate

#convert values to strings with decimals replaced
save_frequency = proxyConv.basicFloatConversion(frequency)

#save ytrue
ytrue11_save_name = "{0}ytrueData_11_Params_Env_{1}_{2}Hz_{3}m.txt".format(
    data_save_path,file_type, save_frequency, layer_thickness)

print("Saving ytrue 11 parameter values as: ", ytrue11_save_name)

#save parameter values
param_values_save_name = "{0}param_values_11_Params_Env_{1}_{2}Hz_{3}m.txt".format(
    param_values_save_path,file_type, save_frequency, layer_thickness)


#check if directories exists
data_directory_check = os.path.isdir(data_save_path)
params_directory_check = os.path.isdir(param_values_save_path)

if data_directory_check == False:
    print("Warning---directory to save data in not found. Check name. Exitting program.")
else:
    np.savetxt(ytrue11_save_name, ytrue11)
    print("ytrue values saved succesfully.")

if params_directory_check == False:
    print("Warning---directory to parameter values not found. Check name. Exitting program.")
else:
    np.savetxt(param_values_save_name, param_values)
    print("Parameter values saved succesfully.")




