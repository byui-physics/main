"""
v1.: Created 5/2/2020
v2.: Created 9/24/2020
Programmer: Hadassah B. Griffin
Contact: hadassahbmeyer@gmail.com
Program: "Calculate_Contour_Cost.py"
Purpose: calculate the cost of varying two parameters and plot their cost

Notes on v2: streamlined/refactored version of v1, created for program clarity
and to debug some issues encountered when creating the contour plots generated
for ORCA transmission loss plots.

"""
#calculate the cost



print("Beginning caluclation of contour cost...")

#following code originally based on CalculateError.py and modified accordingly
import numpy as np
from orca_interface import ORCA
import toml
import sys
import os
import pylab
import matplotlib.pyplot as plt
import time
from ProxyNameConverter import ProxyNameConverter

#track run time
start = time.time()

sys.path.append("./")
from Environments import Environment
print("Using Environments package.")

#ORCA parameters to help create environment
zmin = 10
zmax = 74
zstep = 1
# zr = np.arange(zmin, zmax + zstep, zstep)
zr = np.linspace(zmin, zmax, 256)
r = [9]

#-----Parameters to modify each run for desired environment------#
layer_thickness = 35
environment_type = "clay_iso"
frequency = 100
Nx = 9  #parameter number for x-axis of contour
Ny = 10 #parameter number for y-axis of contour
left_bound_Nx = -4 #range of how far to vary Nx, Ny
right_bound_Nx = 4
left_bound_Ny = -4
right_bound_Ny = 4
num_data_points_Nx = 30 #int, 40 X 40 will run in about 5 minutes
num_data_points_Ny = 30 
use_found_best_fit = False
#----------------------------#
#-----Directories to search for --------#
#file path to get TOML information for environments and to identify
    #where plot info is saved
environment_file_path = "./svp_toml/iso_{0}m/".format(layer_thickness)
data_save_path = "data/error_contour_v2/contours_11_Param_model/"
#default fit save path: "data/error_contour/error_contour_7_Params/"
new_best_fit_directory = "data/calculated_best_fits/" #used if using found fit
number_of_parameters_in_fit = 9 #important to call best fit file with this data
#----------------------------#

#create proxy values for possible decimal place values; this will prevent data
   #loading and plotting issues later
conv = ProxyNameConverter(frequency)
saveNameFrequency = conv.basicFloatConversion(frequency)
saveNameNxLeftBound = conv.basicFloatConversion(left_bound_Nx) 
saveNameNxRightBound = conv.basicFloatConversion(right_bound_Nx) 
saveNameNyLeftBound = conv.basicFloatConversion(left_bound_Ny) 
saveNameNyRightBound = conv.basicFloatConversion(right_bound_Ny)

#if file directory to save in does not exist, stop program and warn user
if (os.path.isdir(data_save_path)) != True:
    
    print("Warning: directory to save data does not exist.")
    print("Directory searched for: ", data_save_path)
    print("Exitting program. Calculation not done.")
    sys.exit()

#creating ORCA environment with base parameters
env = Environment(environment_file_path, environment_type, frequency, zr, r)
env.orca.opt.iikpl = 2  # originally 1
env.orca.opt.db_cut = 120
env.orca.opt.phfac = 8

#call new best fit parameters if this is required; if miscalled, load default
   #else, do default parameters
if use_found_best_fit == True:
    print("Will load found best parameters that were previously calculated.")

    NBF_load_name = "{0}best_fit_params_{1}_model_{2}_{3}Hz_{4}m.txt".format(new_best_fit_directory, number_of_parameters_in_fit, environment_type, saveNameFrequency, layer_thickness)
    print("New best fit parameter data will be loaded from ", NBF_load_name)

    NBF_file_check = os.path.exists(NBF_load_name)

    if NBF_file_check == True:
        print("File loaded successfully.")
        xtrue = np.loadtxt(NBF_load_name)
    else:
        print("File not found. Defaulting to current model values.")
        xtrue = env.x_current()
else: #if xtrue is current model
    print("Using default parameters for model...")
    xtrue = env.x_current()


#Contains calculated error values
y0 = env.y(xtrue) #model to compare with

#calculate the parameter values to test over
xParamShiftValues = np.linspace(left_bound_Nx, right_bound_Nx, num_data_points_Nx)
yParamShiftValues = np.linspace(left_bound_Ny, right_bound_Ny, num_data_points_Ny)

#create Cost Array to hold calculated Cost values
print("Creating cost array to hold cost values for contour plot...")
costValues = np.zeros((num_data_points_Nx, num_data_points_Ny))
xParamValuesShiftIndex = np.arange(num_data_points_Nx)
yParamValuesShiftIndex = np.arange(num_data_points_Ny)

print("The initial parameter values: ", xtrue)

#run calculation---append calculated error to an array
#error---different values than before
for dx in xParamValuesShiftIndex:
    for dy in yParamValuesShiftIndex:

        x = xtrue.copy()
        
        error = 0.5*np.sum((y0 - env.y(x))**2)

        costValues[dx][dy] = error

#save the data to be plotted elsewhere
dataSaveName = "{0}Env_{1}_{2}m_{3}Hz_ParX_{4}_ParY_{5}_LBX_{6}_RBX_{7}_LBY_{8}_RBY_{9}_linx_{10}_liny_{11}.txt".format(data_save_path, environment_type, layer_thickness, saveNameFrequency, Nx, Ny, saveNameNxLeftBound, saveNameNxRightBound, saveNameNyLeftBound, saveNameNyRightBound, num_data_points_Nx, num_data_points_Ny)

print("Now saving file name: ", dataSaveName)

np.savetxt(dataSaveName, costValues)

#end time recording
end = time.time()
print("Total run time: ")
print(end - start)
    

