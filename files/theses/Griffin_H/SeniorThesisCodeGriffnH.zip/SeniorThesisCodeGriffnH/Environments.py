import numpy as np
from orca_interface import ORCA
import numdifftools as nd
import pdb

class Environment:


    def __init__(self, file_path, file_type, frequency, zr, r, rmin = 0.13):
        self.rmin = rmin
        self.orca = ORCA(file_type, base_svp = "{path}/svp_{type}.toml".format(path = file_path, type = file_type))
        self.frequency = frequency
        self.zr = zr #positions at which we evalualte our function (Quantities
        self.r = r   #of interest)
        
        # Set these ORCA params
        zmode = np.linspace(10, 74, 256).tolist()
        zmode.insert(0, 6)
        self.orca.set_frequency(frequency)
        self.orca.set_tl_grid(zr, r)
        self.orca.set_mode_grid(zmode)
        self.orca.opt.rmin = self.rmin
        
        self.orca.run()
        self.M = len(self.orca.tl.flatten()) #number of predictions "M"
        
        self.initialize_internal_params()

        # Get the list of parameters that are being varied; initial values
        self.initial_x = self.x_current().copy()

    def initialize_internal_params(self):
        # Save some variables for internal calculations:
        self.lam_ocean = 0.5*(self.orca.svp.ocean_layers[0][1] + self.orca.svp.ocean_layers[1][1])/self.frequency
        self.lam_1 = 0.5*(self.orca.svp.sediments[0].cp1 + self.orca.svp.sediments[0].cp2)/self.frequency
        self.lam_hsp = self.orca.svp.sediments[-1].cp1/self.frequency

    def run_orca_internal_params(self, xx):

        xxx = xx/1
        self.orca.tl = None
        self.orca.svp.ocean_layers[-1][0] = xxx[0]*self.lam_ocean
        self.orca.svp.sediments[0].h = xxx[1]*self.lam_1
        self.orca.svp.sediments[0].cp1 = xxx[2]*self.lam_1*self.frequency
        self.orca.svp.sediments[0].cp2 = xxx[3]*self.lam_1*self.frequency
        self.orca.svp.sediments[0].rho1 = np.exp(xxx[4])
        self.orca.svp.sediments[0].rho2 = np.exp(xxx[5])
        self.orca.svp.sediments[0].ap1 = np.exp(xxx[6])
        self.orca.svp.sediments[0].ap2 = np.exp(xxx[7])
        self.orca.svp.sediments[-1].cp1 = xxx[8]*self.lam_hsp*self.frequency
        self.orca.svp.sediments[-1].rho1 = np.exp(xxx[9])
        self.orca.svp.sediments[-1].ap1 = np.exp(xxx[10])
        
        
        """
        catch potential errors from bound calculations so program keeps running
        """
        try:
            self.orca.run()
            return self.orca.tl.flatten()
        except:
            return np.ones(self.M) * np.inf

    def internal_params(self, x):
        return np.array([
            np.exp(x[0])/self.lam_ocean,
            np.exp(x[1])/self.lam_1,
            np.exp(x[2])/(self.lam_1*self.frequency),
            np.exp(x[3])/(self.lam_1*self.frequency),
            x[4],
            x[5],
            x[6],
            x[7],
            np.exp(x[8])/(self.lam_hsp*self.frequency),
            x[9],
            x[10]
            ])*1

    def jacobian_internal_params(self, x):
        return np.diag([
            np.exp(x[0])/self.lam_ocean,
            np.exp(x[1])/self.lam_1,
            np.exp(x[2])/(self.lam_1*self.frequency),
            np.exp(x[3])/(self.lam_1*self.frequency),
            1.0,
            1.0,
            1.0,
            1.0,
            np.exp(x[8])/(self.lam_hsp*self.frequency),
            1.0,
            1.0]
        )*1

    def y(self, x):
        # Construct internal parameters that give stable finite difference
        #derivatives
        xx = self.internal_params(x)
        return self.run_orca_internal_params(xx)

    def dy(self, x, dx):
        # Construct internal parameters that give stable finite difference
        #derivatives
        xx = self.internal_params(x)
        dxx = np.dot(self.jacobian_internal_params(x), dx)
        dr_nd, info = nd.directionaldiff( self.run_orca_internal_params, xx,
                                          dxx, full_output = True,
                                          method = "forward")        
        return dr_nd

    def jacobian(self, x):
    
        return np.asarray( [self.dy(x, dx) for dx in np.eye(len(x))]).T
        
    def x_current(self):
        return np.array([
            np.log(self.orca.svp.ocean_layers[-1][0]),
            np.log(self.orca.svp.sediments[0].h),
            np.log(self.orca.svp.sediments[0].cp1),
            np.log(self.orca.svp.sediments[0].cp2),
            np.log(self.orca.svp.sediments[0].rho1),
            np.log(self.orca.svp.sediments[0].rho2),
            np.log(self.orca.svp.sediments[0].ap1),
            np.log(self.orca.svp.sediments[0].ap2),
            np.log(self.orca.svp.sediments[-1].cp1),
            np.log(self.orca.svp.sediments[-1].rho1),
            np.log(self.orca.svp.sediments[-1].ap1),
        ])
