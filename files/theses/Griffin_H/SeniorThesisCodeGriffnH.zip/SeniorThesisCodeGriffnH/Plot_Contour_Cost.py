"""
6/11/2020

-Programmer: Hadassah B. Meyer
-Purpose: create contour plots based on error calculations made in 
 Calculate_Contour_Cost.py; additionally,
 superimpose values from likelihood profiles to see if the optimizer for the 
 likelihood calculator is working sufficiently for the problem at hand.

-Important program notes:

   -Superimposed likelihood function:
      -You must match the x-parameter of the cost and likelihood function, and 
        y-parameter of cost and likelihood;
        otherwise, there is just a linear relationship if you plot x vs x on 
        likelihood, which is not interesting;
        to compare a likelihood superimpsition with others, create seperate 
        plots, save them or copy them somewhere else
"""
def main():

    import numpy as np
    import matplotlib.pyplot as plt
    import os
    import sys
    import pylab

    #-----Parameters to modify each run for desired environment------#
    env_param_model = "9 Parameter Model Simplex" #plot title piece
    layer_thickness = 35
    file_type = "sand_iso"
    frequency = 100
    Nx = 5  #parameter number for x-axis of contour
    Ny = 8 #parameter number for y-axis of contour
    LB_x = -4 #bounds on lin space ranges; int or float
    RB_x = 4
    LB_y = -4
    RB_y = 4
    lin_space_x_range = 30 
    lin_space_y_range = 30 
    #-------Additional adjustable parameters if "superimposeLikelihoodValues"
    #-------is true------#
    Nx_lh = Nx
    Ny_lh = Ny   
    left_bound_1 = -4
    right_bound_1 = 4
    left_bound_2 = -4
    right_bound_2 = 4
    
    #----------------------------#

    #-----File paths-----------#
    plot_save_path = "plots/error_contours_plots/"
    data_save_path_cost = "data/error_contour_v2/contours_9_Param_model/"
    file_lh_data_path = "data/likelihood_9_Params_simplex/found_fit/env_sand/"

    #-----Plot type options-----#
    logCostPlotCase = True
    superimposeLikelihoodValues = True
    constrainLikelihoodPlotLimits = False
    #-------------------------#

    #parameters selected depend on the model---comment out unused ones
    #
    
    paramLabels = [r"$hw$",
                   r"$h_1$",
                   r"$c_1$",
                   r"$c_2$",
                   r"$\rho_1$",
                   r"$\rho_2$", #9 and higher model dimensions---no ratio 
                  # r"$\rho_2 / \rho_{hsp}$",#ratio for 8 parameter versionn  
                   r"$\alpha_1$",
                   r"$\alpha_2$",
                   #r"$c_{hsp}$",
                   r"$\rho_{hsp}$",
                   #r"$\alpha_{hsp}$"
    ]
   
    #create proxy values for possible decimal place values;
    #this will prevent data loading and plotting issues later
    proxyFrequency = str(frequency)
    decimalCheckFrequency = proxyFrequency.find('.')
    proxyLBx = str(LB_x)
    proxyRBx = str(RB_x)
    decimalCheckLBx = proxyLBx.find('.')
    decimalCheckRBx = proxyRBx.find('.')
    proxyLBy = str(LB_y)
    proxyRBy = str(RB_y)
    decimalCheckLBy = proxyLBy.find('.')
    decimalCheckRBy = proxyRBy.find('.')
    
    if decimalCheckFrequency != -1:
        proxyFrequency = proxyFrequency.replace('.','o')
    if decimalCheckLBx != -1:
        proxyLBx = proxyLBx.replace('.','o')
    if decimalCheckRBx != -1:
        proxyRBx = proxyRBx.replace('.','o')
    if decimalCheckLBy != -1:
        proxyLBy = proxyLBy.replace('.','o')
    if decimalCheckRBy != -1:
        proxyRBy = proxyRBy.replace('.','o')

    #---additional proxy checks for superimposeLikelihoodData option----#
    proxyLeftB1 = str(left_bound_1)
    proxyRightB1 = str(right_bound_1)
    decimalCheckLB1 = proxyLeftB1.find('.')
    decimalCheckRB1 = proxyRightB1.find('.')
    proxyLeftB2 = str(left_bound_2)
    proxyRightB2 = str(right_bound_2)
    decimalCheckLB2 = proxyLeftB2.find('.')
    decimalCheckRB2 = proxyRightB2.find('.')
    

    if decimalCheckLB1 != -1:
        proxyLeftB1 = proxyLeftB1.replace('.','o')
    if decimalCheckRB1 != -1:
        proxyRightB1 = proxyRightB1.replace('.','o')
    if decimalCheckLB2 != -1:
        proxyLeftB2 = proxyLeftB2.replace('.','o')
    if decimalCheckRB2 != -1:
        proxyRightB2 = proxyRightB2.replace('.','o')
    
    #build the name for the cost data
    dataZSetFileName = "{0}Env_{1}_{2}m_{3}Hz_ParX_{4}_ParY_{5}_LBX_{6}_RBX_{7}_LBY_{8}_RBY_{9}_linx_{10}_liny_{11}.txt".format(data_save_path_cost,
                                file_type, layer_thickness, proxyFrequency, Nx,
                                Ny, proxyLBx, proxyRBx, proxyLBy, proxyRBy,
                                lin_space_x_range, lin_space_y_range)
    saveExtension = ""
    
    #file data paths for "superimposeLikelihoodValues" plots option, "lh"
    #file name assembled---extension to where it is saved is contained in
    #file_data_path variable
    data_lh_file_name_Nx = "{0}Env_{1}_{2}_{3}m_l{4}_r{5}_{6}.npy".format(file_lh_data_path, file_type, proxyFrequency, layer_thickness, proxyLeftB1, proxyRightB1, Nx_lh)
    data_lh_file_name_Ny = "{0}Env_{1}_{2}_{3}m_l{4}_r{5}_{6}.npy".format(file_lh_data_path, file_type, proxyFrequency, layer_thickness, proxyLeftB2, proxyRightB2, Ny_lh)

    if superimposeLikelihoodValues == True:
        print("Searching for: ", data_lh_file_name_Nx)
        print("Searching for: ", data_lh_file_name_Ny)

    #check if saved names exist before running calculations
    run_calculations = True #flag to go ahead on calculations
    
    lh_directory_check = os.path.isdir(file_lh_data_path)
    lh_Nx_file_check = os.path.exists(data_lh_file_name_Nx)
    lh_Ny_file_check = os.path.exists(data_lh_file_name_Ny)
    cost_directory_check = os.path.isdir(data_save_path_cost)
    cost_file_check = os.path.exists(dataZSetFileName)

    #deactivate calcuations if cost data file and directory not found
    if cost_directory_check == False:
        print("Warning---directory for cost data not found. Check name of directory path. Exitting program.")
        run_calculations = False
    if cost_file_check == False:
        print("Warning--file for cost data not found. Check name of file. Exitting program.")
        print("File name searched for: ", dataZSetFileName)
        run_calculations = False

    #deactivate calcuations if likelihood file and directory not found,
    #if needed for plot
    if superimposeLikelihoodValues == True:
        if lh_directory_check == False:
            print("Warning---directory for likelihood data not found. Check name of directory path. Exitting program.")
            run_calculations = False
        if lh_Nx_file_check == False:
            print("Warning: likelihood file for Nx paramter not found. Check name of file. Exitting program")
            run_calculations = False
        if lh_Ny_file_check == False:
            print("Warning: likelihood file for Ny paramter not found. Check name of file. Exitting program")
            run_calculations = False        
    
    #run plot creations if all data required is found
    if run_calculations == True:

        #calculate the linear spaces for x, y for contour plot
        xContour = np.linspace(LB_x, RB_x, lin_space_x_range)
        yContour = np.linspace(LB_y, RB_y, lin_space_y_range)

        #Load data
        dataZSet = np.loadtxt(dataZSetFileName)
        print("Data z array has shape: ", np.shape(dataZSet))
        
        xRecursive = np.arange(lin_space_x_range)
        yRecursive = np.arange(lin_space_y_range)

        #Adpat the data to a new cost function that zooms in on the data:
        #log(cost + 1e-2)
        if logCostPlotCase == True:
            print("Creating log plot option.")
            #cost plot scaling
            for i in xRecursive:
                for j in yRecursive:
                    dataZSet[i][j] = np.log(dataZSet[i][j] + 0) #set to 1e-2 so
                                                       #scale is not swamped
            saveExtension = "_logCost"


        #Create Contour Plot
        print("Preparing to plot contour cost...")

        #create contour plots
        plt.contourf(xContour, yContour, dataZSet.T, zorder = 1, alpha = 0.5) #Transpose ensures that whether x or y is bigger, the plot works
        plt.colorbar()
        plt.ylabel(paramLabels[Ny])
        plt.xlabel(paramLabels[Nx])
        plt.title("{0} {1} {2}m {3}Hz".format(env_param_model, file_type, layer_thickness, frequency ))

        if superimposeLikelihoodValues == False:
            plt.show()

        if superimposeLikelihoodValues == True:
            print("Superimposing likleihood values for likelihood profiles of {0} and {1}".format(paramLabels[Nx], paramLabels[Ny]))
            #import the data
            dataLHNx = np.load(data_lh_file_name_Nx)
            dataLHNy = np.load(data_lh_file_name_Ny)

            #check sizes of the arrays---the must be the same to be counted in
            #the scatter plot. To determine
            #wheter to remove data from the end or beginning of the array, see
            #the data set.
                
            NxDim = np.shape(dataLHNx)
            NyDim = np.shape(dataLHNy)

            print("Size of NxDim: ", NxDim)
            print("Size of NyDim: ", NyDim)

            #conditions of not cut active until proven there needs to be
            #cutting done
            NxDataCutCondition = False
            NyDataCutCondition = False

            if NxDim != NyDim:
                print("Sizes of likelihood profile arrays do not match---deleting an end of array to match the sizes...")
                print("Notice---this program currently only adjusts row space. Functions for column space adjustment must be coded in still.")
                #create range of numbers for data to delete---row case
                if NxDim[0] != NyDim[0]:
                    print("Row spaces not the same in both array.")
                    if NxDim > NyDim:
                        maxArrayValueRow = NxDim[0]
                        newMaxArrayValueRow = NyDim[0]
                    if NxDim < NyDim:
                        maxArrayValueRow = NyDim[0]
                        newMaxArrayValueRow = NxDim[0]
                    print(maxArrayValueRow)
                    print(newMaxArrayValueRow)

                    #create new space

                    cutRowSpace = np.arange(newMaxArrayValueRow,
                                            maxArrayValueRow, 1)
                    
                if NxDim[1] != NyDim[1]:
                    print("Warning: no code created yet for adapting column space. More work will need to be done to adapt code. Expect errors.")
                    
                #conditions of not cut active until proven there needs to be
                #cutting done
                NxDataCutCondition = False
                NyDataCutCondition = False
                
                if NxDim > NyDim:
                    cutData = np.copy(dataLHNx)
                    print("Size of cut for dataLHNx: ", np.shape(cutData))
                    print("Cut down to: ", np.shape(dataLHNy))
                    NxDataCutCondition = True

                    if initialGuessValues == True:
                        cutIGSData = np.copy(dataIGSNx)
                else:
                    cutData = np.copy(dataLHNy)
                    print("Size of cut data for dataLHNy: ", np.shape(cutData))
                    print("Cut down to: ", np.shape(dataLHNx))
                    NyDataCutCondition = True

                cutData = np.delete(cutData, cutRowSpace, axis = 0)

            #extract data
            #NxDataCutCondition
            if NxDataCutCondition == True:
                xLHValsNx = cutData[:,Nx_lh] #get the parameter values for the
                                             #Nx value in this Nx data set
                yLHValsNx = cutData[:,Ny_lh] #get the parameter values for the
                                             #Ny value in this Nx data set
                
            else:
                xLHValsNx = dataLHNx[:,Nx_lh]
                yLHValsNx = dataLHNx[:,Ny_lh]


            if NyDataCutCondition == True:
                xLHValsNy = cutData[:,Nx_lh] 
                yLHValsNy = cutData[:,Ny_lh] 
            else:
                xLHValsNy = dataLHNy[:,Nx_lh]
                yLHValsNy = dataLHNy[:,Ny_lh]

            
            #scatter plot for Nx values, represented by dots
            plt.scatter(xLHValsNx, yLHValsNx, c = "b", marker = "o", zorder = 2)

            #scatter plot for Ny vlaues, represented by x's
            plt.scatter(xLHValsNy, yLHValsNy, c = "r", marker = "o", zorder = 3)

            plt.legend(["Blue = LH {0}".format(
                paramLabels[Nx_lh]), "Red = LH {0}".format(paramLabels[Ny_lh])])

            #show plot
            plt.show()
        
            #set the limits of the likelihood parameters to match the limits
            #of the contour plot
            if constrainLikelihoodPlotLimits == True:
                
                plt.xlim(LB_x, RB_x)
                plt.ylim(LB_y, RB_y)
                print("Data points visible constrained to limits of the contour plot.")

            #set save extensions
            if logCostPlotCase == False:
                print("Linear case plot: ")
                saveExtension = "_LH_linear"
            else:
                print("Scatter option for log plot case: ")
                saveExtension = "_LH_log"

            if constrainLikelihoodPlotLimits == True:
                saveExtension += "_constrained"
        
        #ask user if saving file wanted   
        saveFileQuery = input("Save this plot? <y>\" yes\"; any other key, \"no\"   ")
        print(saveFileQuery)

        if saveFileQuery == "y":

            plotSaveName = "{0}Env_{1}_{2}m_{3}Hz_ParX_{4}_ParY_{5}_LBX_{6}_RBX_{7}_LBY_{8}_RBY_{9}_linx_{10}_liny_{11}_{12}".format(plot_save_path, file_type, layer_thickness, proxyFrequency, Nx, Ny, proxyLBx, proxyRBx, proxyLBy, proxyRBy, lin_space_x_range, lin_space_y_range, saveExtension)

            existing_plot_name = plotSaveName + ".png"
            #check if file exists already to avoid over-write
            file_exist_check=os.path.exists(existing_plot_name)
            if file_exist_check == True:
                overwriteFileQuery= input("File already exists. Overwrite saved file? <y> for \"yes\", any other key for no  ")

                #ovewrite access query
                if overwriteFileQuery == "y":
                    print("Overwriting file ", plotSaveName)
                    plt.savefig(plotSaveName)
                else:
                    print("File not overwritten.")

            else:
                print("Saving file as ", plotSaveName)
                plt.savefig(plotSaveName)
           

if __name__ == "__main__":
    main()
