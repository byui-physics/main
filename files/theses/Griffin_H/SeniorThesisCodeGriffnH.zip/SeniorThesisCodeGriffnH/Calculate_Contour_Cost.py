"""
5/2/2020
Programmer: Hadassah B. Meyer
Program: "Calculate_Contour_Cost.py"
Purpose: calculate the cost of varying two parameters and plot their cost

"""
#calculate the cost

def main():

    print("Beginning caluclation of contour cost...")
    #note: .T is necassary for the Cost/z values before getting plotted to
    #avoid syntax errors in some configuration like a bigger y dimension than x;

    #following code based on CalculateError.py and modified accordingly
    import numpy as np
    from orca_interface import ORCA
    import toml
    import sys
    import os
    import pylab
    import time

    #track run time
    start = time.time()

    sys.path.append("./")
    from Environments_9_Fixed_Params import Environment
    print("Using Environments_9_Fixed_Params.py package.")

    #ORCA parameters to help create environment
    zmin = 10
    zmax = 74
    zstep = 1
    zr = np.linspace(zmin, zmax, 256)
    r = [9]

    #-----Parameters to modify each run for desired environment------#
    layer_thickness = 35
    file_type = "gravel_iso"
    frequency = 100
    Nx = 0  #parameter number for x-axis of contour
    Ny = 1 #parameter number for y-axis of contour
    LB_x = 5 #bounds on lin space ranges; int or float
    RB_x = 11
    LB_y = -5
    RB_y = 5
    lin_space_x_range = 100 
    lin_space_y_range = 100
    use_found_best_fit = False
    #----------------------------#
    #-----Directories to search for --------#
    #file path to get TOML information for environments and to identify
    #where plot info is saved
    file_path = "./svp_toml/iso_{0}m/".format(layer_thickness)
    data_save_path = "data/error_contour/error_contour_9_Fixed_Params/"
    new_best_fit_directory = "data/calculated_best_fits/" 
    number_of_parameters_in_fit = 7 #important to call file with this data
    #----------------------------#
    
    #create proxy values for possible decimal place values; this will prevent
    #data loading and plotting issues later
    proxyFrequency = str(frequency)
    decimalCheckFrequency = proxyFrequency.find('.')
    proxyLBx = str(LB_x)
    proxyRBx = str(RB_x)
    decimalCheckLBx = proxyLBx.find('.')
    decimalCheckRBx = proxyRBx.find('.')
    proxyLBy = str(LB_y)
    proxyRBy = str(RB_y)
    decimalCheckLBy = proxyLBy.find('.')
    decimalCheckRBy = proxyRBy.find('.')


    if decimalCheckFrequency != -1:
        proxyFrequency = proxyFrequency.replace('.','o')
    if decimalCheckLBx != -1:
        proxyLBx = proxyLBx.replace('.','o')
    if decimalCheckRBx != -1:
        proxyRBx = proxyRBx.replace('.','o')
    if decimalCheckLBy != -1:
        proxyLBy = proxyLBy.replace('.','o')
    if decimalCheckRBy != -1:
        proxyRBy = proxyRBy.replace('.','o')


    #creating ORCA environment
    env = Environment(file_path, file_type, frequency, zr, r)
    env.orca.opt.iikpl = 2  # originally 1
    env.orca.opt.db_cut = 120
    env.orca.opt.phfac = 8
        
    #call new best fit parameters if this is required; if miscalled,
    #load default
       #else, do default parameters
    if use_found_best_fit == True:
        print("Will load found best parameters that were previously calculated.")
        
        NBF_load_name = "{0}best_fit_params_{1}_model_{2}_{3}Hz_{4}m.txt".format(
            new_best_fit_directory, number_of_parameters_in_fit, file_type,
            proxyFrequency, layer_thickness)
        print("New best fit parameter data will be loaded from ", NBF_load_name)

        NBF_file_check = os.path.exists(NBF_load_name)

        if NBF_file_check == True:
            print("File loaded successfully.")
            xtrue = np.loadtxt(NBF_load_name)
        else:
            print("File not found. Defaulting to current model values.")
            xtrue = env.x_current()
            
    else: #if xtrue is current model
        print("Using default parameters for model...")
        xtrue = env.x_current()


    #Contains calculated error values
    error = []
    y0 = env.y(xtrue)

    #calculate the linear spaces for x, y
    xContour = np.linspace(LB_x, RB_x, lin_space_x_range)
    yContour = np.linspace(LB_y, RB_y, lin_space_y_range)

    #create zSet ndarray to contain cost values
    print("Creating zSet for contour plot to hold values...")
    zSet = np.zeros((lin_space_x_range, lin_space_y_range))
    xRecursive = np.arange(lin_space_x_range)
    yRecursive = np.arange(lin_space_y_range)
    
    print("The initial parameter values: ", xtrue), 
    
    #run calculation---append calculated error to an array
    #error---different values than before
    for dx in xRecursive:
        for dy in yRecursive:

            x = xtrue.copy()
            """
            what happens here: for the particular parameter, the value gets 
            shifted.
            So, when the new error calculated (done within the function itself),
            this new
             shift is accounted for!
            The xContour and yContour contain the linspace shifting values; 
            they get
                called in order to do this calculation
            """
            x[Nx] = x[Nx] + xContour[dx]
            x[Ny] = x[Ny] + yContour[dy]
            error.append(0.5*np.sum((y0 - env.y(x))**2))
            zSet[dx][dy] = error[-1]

    print("End array: ", zSet)
    
    #save the data to be plotted elsewhere
    dataSaveName = "{0}Env_{1}_{2}m_{3}Hz_ParX_{4}_ParY_{5}_LBX_{6}_RBX_{7}_LBY_{8}_RBY_{9}_linx_{10}_liny_{11}.txt".format(data_save_path, file_type,                                                      layer_thickness, proxyFrequency,                                                Nx, Ny, proxyLBx, proxyRBx,
                                            proxyLBy, proxyRBy,
                                            lin_space_x_range,
                                            lin_space_y_range)
    print("Now saving file name: ", dataSaveName)

    np.savetxt(dataSaveName, zSet)
            
    #end time recording
    end = time.time()
    print("Total run time: ")
    print(end - start)
    

if __name__ == "__main__":
    main()
