"""
Created 6/25/2020 by Dr. Transtrum.
Last update: 7/9/2020
Purpose: Find the best set up for the optimization algorithim and the 
11 ORCA parameter model that finds
the minimum.

-Note: to create the ytrue/data to compare against, use the 
11 parameter/original model in "Data_Generator_11_Param_Model.py

"""



import sys
import os
sys.path.append("./") # current folder
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import leastsq, fmin
from orca_interface import ORCA
from Environments import Environment
import time
from ProxyNameConverter import ProxyNameConverter #makes loading the saved file
 #easier

################################################################################
#Set up time
################################################################################
start = time.time()


################################################################################
# Setting up environment
################################################################################

zmin = 10
zmax = 74
zstep = 1
zr = np.linspace(zmin, zmax, 256)
r = [9]

frequency = 100
file_type = "gravel_iso"
layer_thickness = 35
file_path = "./svp_toml/iso_{0}m/".format(layer_thickness) #locates toml files
data_save_path = "data/data_ytrue_11_Params/"

env = Environment(file_path, file_type, frequency, zr, r, rmin = 1.5)

#Load name value adjustments
#instantiate ProxyNameConverter.py instance
proxyConv = ProxyNameConverter(file_type) #dummy variable to initiate
load_frequency = proxyConv.basicFloatConversion(frequency)


################################################################################
# Done
################################################################################


################################################################################
# Setting up fitting problem
################################################################################
noise_scalar = 0

#inquire user is loading best fit parameters of current model or from "Find_New_Best_Fits.py" data
print("You may choose to load data from the current model set in this program, or use the \"Find_New_Best_Fits.py\" data. Enter <1> to use current model data. Enter <2> to load calcualted best fit parameters. All other entries will default to the current model calcualted parameters.")

new_best_fit_directory = "data/calculated_best_fits/"

paramLoadQuery = input("Enter your option here: ")
print(paramLoadQuery)

if paramLoadQuery == "2":

    result_size = input("Enter number of parameters in model that is being called (1-10): ")
    
    #check if directory exists:
    NBF_load_name = "{0}best_fit_params_{1}_model_{2}_{3}Hz_{4}m.txt".format(new_best_fit_directory, result_size, file_type, load_frequency, layer_thickness)
    print("New best fit parameter data will be loaded from ", NBF_load_name)

    NBF_file_check = os.path.exists(NBF_load_name)

    if NBF_file_check == True:
        print("File loaded successfully.")
        x = np.loadtxt(NBF_load_name)
    else:
        print("File not found. Defaulting to current model values.")
        x = env.x_current()
else: #if x is current model
    x = env.x_current()

np.random.seed(0)
xi = x + np.random.randn(len(x))*noise_scalar


#Load ytrue from 11 parameter model---calculated in
#Data_Generator_11_Param_Model.py

#Buildng load name
ytrue11_load_name = "{0}ytrueData_11_Params_Env_{1}_{2}Hz_{3}m.txt".format(data_save_path, file_type, load_frequency, layer_thickness)
print("Loading ytrue 11 data from file: ", ytrue11_load_name)
ytrue = np.loadtxt(ytrue11_load_name)
#ytrue for tester toy model

#ytrue = env.y(x)

#just load this for shape comparison
ytrueCurrentModel = env.y(x)
shapeytrueCurrentModel = np.shape(ytrueCurrentModel)

"""
Load a previously calculated ytrue from the 11 parameter model and use that 
to compare;
otherwise, trivially zero after the first step every time

"""
def residuals(x):
    #print("Evaluating model at x = ", x)
    r = ytrue - env.y(x)
    #print("Cost = %.2e" %(sum(r**2)/2))
    return r

def dresiduals(x):
    return -env.jacobian(x)

def Cost(x):
    return sum(residuals(x)**2)/2

################################################################################
# Done
################################################################################


################################################################################
# Do fit using Simplex method
################################################################################


print("Calculating...:")
result, fopt, iter, funcalls, warnflag = fmin(Cost, xi,
                                              full_output = 1,
                                              #maxiter = 3
                                              )
print("Cost at fit x: %.2e" %(Cost(result)))
print("Change in parameter values: ", result - xi)

print("X before noise: ", x)
print("x with noise: ", x + np.random.randn(len(x))*noise_scalar)
print("noise: ", np.random.randn(len(x))*noise_scalar)


################################################################################
#Print out end time and ytrue shape for reference
################################################################################
end = time.time()
print("Time elapsed: ", end - start)
print("Shape of ytrue loaded: ", np.shape(ytrue))
print("Shape of current environment ytrue: ", shapeytrueCurrentModel)

