"""
Differs from original in that another kwargs argument is added in order to add 
more identifying information to an exported file. The kwarg is called 
"extra_identifiers." Also, the simplex method is used instead of the Levenburg-
Marquedt from the version.


3/6/2021
Cost value will be saved with fopt, not the cost value at the initial guess


"""
import numpy as np
import scipy.optimize as opt
import multiprocessing as mp
import sys
import pdb

"""
Python package to compute data for likelihood profile.
"""

__all__ = ["likelihood", "likelihood_all"]

# Define the residual function
def residual(params_to_fit, fixed_params, i, model, true_values, std_values=1):
    parameters = np.insert(params_to_fit, i, fixed_params)
    return np.abs((true_values - model(parameters))/std_values)

#Define the cost function for fmin/simplex method
def Cost(params_to_fit, fixed_params, i, model, true_values, std_values=1):
    return sum(residual(params_to_fit, fixed_params, i, model, true_values, std_values=1)**2)/2

def likelihood(model, best_fit, idx_params, **kwargs):

    """
    Function to calculate the likelihood profile of a model for 1 parameter.   |
    The calculation is done by fixing 1 model's parameter and optimize
    over the rest of the parameters to obtain the minimum cost. The cost
    is calculated by:
    cost = (1/2) * sum(((prediction - data)/sigma)^2)

    Parameters
    ----------
    model : Function
        Function that take a 1D numpy array and return the predictions
        as a 1D numpy array.

    best_fit : Array
        Best fit parameters of the model.

    idx params : Int
        Index of the parameters to calculate.

    **kwargs
    --------
    bound : Array
        An 1 x 2 array with format [lower_bound, upper_bound].
        (default: [0, 30])

    dt : Float
        Distance between points in the likelihood profile.
        (default: 0.1)

    true_values : Array
        The true data value, can be from experimental data or the
        predictions from more sophisticated models. If left as None,
        then the true value is setup to be the predictions at the best
        fit parameters. (default: [])

    std_values : Array
        Array of the standard deviation. In general, the length of this
        array should be the same as the number of predictions. If there
        is only 1 value give, the standard deviation is assumed to be the
        same for all predictions. Special values: 0 = standard deviation
        is 0.1 * true_values; 1 = like no standard deviation. (default: 1)

    fixed_initial_guess : Array
        An option to specify other fixed initial guess, to get more candidate
        points. This means that these initial guess values will be the same
        for every iteration. (default: if points>0, a list of random numbers
        in the bounds interval)

    export_result : Bool
        Option to export likelihood data as a numpy file. (default: False)

    #save_mod
    extra_identifiers: String
        Option to add details to identify save file. (default: '')

    Return
    ------
    sorted_result : Array
        Likelihood data for the parameter specified, sorted by the fixed
        parameter. The columns of the array represent:
        parameter_0    parameter_1    ...    parameter_N    min(cost)

    """

    error = False
    
    # Unpacking the keyword-arguments
    try:
        bound = kwargs['bound']
    except:
        bound = [0, 30]

    try:
        dt = kwargs['dt']
    except:
        dt = 0.1

    try:
        true_values = kwargs['true_values']
    except:
        true_values = model(best_fit)

    try:
        points = kwargs['points']
    except:
        points = 0

    try:
        fixed_initial_guess = kwargs['fixed_initial_guess']
    except:
        if points > 0:
            fixed_initial_guess = np.zeros((points, len(best_fit)))
            for i in range(points):
                fixed_initial_guess[i] = np.random.uniform(bound[0], bound[1], len(best_fit))
        else:
            pass

    try:
        std_values = kwargs['std_values']
        # Set the standard deviation
        if std_values==0:
            std_values = 0.1 * true_values
        elif np.ndim(std_values)>0 and len(std_values)!=len(true_values):
            error = True
            message = "std_values and true_values should have the same size"
    except:
        std_values = 1

    try:
        export_result = kwargs['export_result']
    except:
        export_result = False

    #save_mod
    try:
        extra_identifiers = kwargs['extra_identifiers']
    except:
        extra_identifiers = ''

    if error:
        raise ValueError(message)

    num_params = len(best_fit)

    print('Calculation for parameter index %s' %(idx_params))

    # Create the parameter list
    param_list_left = np.arange(best_fit[idx_params], bound[0], -dt)
    param_list_right = np.arange(best_fit[idx_params]+dt, bound[1], dt)

    save_mat = np.empty((0, num_params+1))

    # Calculation to the left of the best-fit
    #Set the first last_best to be the best_fit
    initial_guess_array = np.tile(np.delete(best_fit, idx_params), (2, 1))
    if points > 0:
        initial_guess_array = np.row_stack((initial_guess_array,
                                            np.delete(fixed_initial_guess, idx_params, 1)))

    for fixed_param in param_list_left:
        temp = np.zeros((np.shape(initial_guess_array)[0],
                         np.shape(initial_guess_array)[1]+2))
        for i, p in enumerate(initial_guess_array):
            # Skip second calculation if the last best optimized parameters
            # and the optimized parameters started from best fit are the same / very close
            if np.allclose(initial_guess_array[0], initial_guess_array[1]) or points==0:
                skip_idx_1 = True
            else:
                skip_idx_1 = False

            if i==1:
                if skip_idx_1:
                    temp[i] = temp[0]
                    continue
            #pdb.set_trace()
            temp[i] = compute(model, true_values,
                              idx_params, fixed_param,
                              initial_guess_array[i])
            if i==0:
                initial_guess_array[i] = np.delete(temp[i, :-1], idx_params)

        temp = temp[np.argsort(temp[:, -1])]
        initial_guess_array[1] = np.delete(temp[0, :-1], idx_params)
        save_mat = np.row_stack((save_mat, temp[0]))


    # Calculation to the right of the best-fit
    initial_guess_array[0:2] = np.tile(np.delete(best_fit, idx_params), (2, 1))

    for fixed_param in param_list_right:
        temp = np.zeros((np.shape(initial_guess_array)[0],
                         np.shape(initial_guess_array)[1]+2))
        for i, p in enumerate(initial_guess_array):
            # Skip second calculation if the last best optimized parameters
            # and the optimized parameters started from best fit are the same / very close
            if np.allclose(initial_guess_array[0], initial_guess_array[1]) or points==0:
                skip_idx_1 = True
            else:
                skip_idx_1 = False

            if i==1:
                if skip_idx_1:
                    temp[i] = temp[0]
                    continue

            temp[i] = compute(model, true_values,
                              idx_params, fixed_param,
                              initial_guess_array[i])
            if i==0:
                initial_guess_array[i] = np.delete(temp[i, :-1], idx_params)

        temp = temp[np.argsort(temp[:, -1])]
        initial_guess_array[1] = np.delete(temp[0, :-1], idx_params)
        save_mat = np.row_stack((save_mat, temp[0]))

    # Sort the result
    sorted_result = save_mat[save_mat[:, idx_params].argsort()]

    if export_result:
        # Save the result
        if np.ndim(std_values)==0 and std_values==1:
            filename = "{1}_{0}.npy".format(idx_params, extra_identifiers)
            print("It worked: ", filename)
        else:
            filename = 'likelihood_parameter_%s_std.npy' %(idx_params)
        np.save(filename, sorted_result)


    return sorted_result

#does the optimization
def compute(model, true_values, idx_params, fixed_param, initial_guess):   
    
    opt_results, fopt, iter, funcalls, warnflag = opt.fmin(Cost,initial_guess,
                                                           args = (fixed_param,
                                                                   idx_params,
                                                                   model,
                                                                   true_values),
                                                           full_output = 1)
    
    opt_params = opt_results
    cost_value = Cost(initial_guess, fixed_param, idx_params, model,
                      true_values)

    to_save = np.append(np.insert(opt_params, idx_params, fixed_param),
                        cost_value)
    print(to_save)
    return to_save


def likelihood_wrapper(model, best_fit, idx,
                       bound, dt, true_values,
                       std_values,
                       points, fixed_initial_guess):
    if np.ndim(fixed_initial_guess)<2:
        return likelihood(model, best_fit, idx,
                          bound=bound, dt=dt, true_values=true_values,
                          std_values=std_values,
                          points=points,
                          export_result=True,
                          extra_identifiers=extra_identifiers)
    else:
        return likelihood(model, best_fit, idx,
                          bound=bound, dt=dt, true_values=true_values,
                          std_values=std_values,
                          points=points,
                          fixed_initial_guess=fixed_initial_guess,
                          export_result=True,
                          extra_identifiers=extra_identifiers)

def likelihood_all(model, best_fit, **kwargs):

    """
    Function to iterate over all the model parameters and calculate
    the data to get the likelihood profile for each of the parameter.

    Parameters
    ----------
    model : Function
        Function that take a 1D numpy array and return the predictions
        as a 1D numpy array.

    best_fit : Array
        Best fit parameters of the model.

    **kwargs
    --------
    bound : Array
        An 1 x 2 or N x 2 array, where N should be the same as
        len(best_fit), containing the upper bound and the lower bound
        for each parameter. The first column of the array contains the
        lower bound, and the second column contains the upper bound.
        If the input is a 1 x 2 array, then the bound is setup to be
        the same across all parameters.
        (default: [0, 30] for all parameters)

    dt : Array
        Distance between points in the likelihood profile. Each element
        of dt correspond to the distance between 2 points of each
        parameter. (default: 0.1)

    true_values : Array
        The true data value, can be from experimental data or the
        predictions from more sophisticated models. If left as None,
        then the true value is setup to be the predictions at the best
        fit parameters. (default: [])

    std_values : Array
        Array of the standard deviation. In general, the length of this
        array should be the same as the number of predictions. If there
        is only 1 value give, the standard deviation is assumed to be the
        same for all predictions. Special values: 0 = standard deviation
        is 0.1 * true_values; 1 = like no standard deviation. (default: 1)

    fixed_initial_guess : Array
        An option to specify other fixed initial guess, to get more candidate
        points. This means that these initial guess values will be the same
        for every iteration. The typical format is a 3D array, with each
        layer corresponds to different parameter and each row corresponds to
        different points. The values are given in columns. Special case, if
        only 1 2D array is given, then each parameter will have the same
        fixed_initial_guess. (default: if points>0, a list of random numbers
        in the bounds interval)

    threads : Int
        Number of compute threads to use for the calculation. The number
        of threads used should be less than or equal to the number of
        parameters. (default: 1)

    Return
    ------
    Numpy files of the data of the likelihood profile of each parameter.
    The data is constructed in array, sorted by the fixed parameter,
    with each column represents:
    parameter_0    parameter_1    ...    parameter_n    min(cost)
    """

    error = False
    num_params = len(best_fit)
    
    # Unpacking the keyword-arguments

    try:
        bound = kwargs['bound']
    except:
        bound = [0, 30]
    # Check and setup the bound array
    if np.ndim(bound)==1:
        # Setup 2D bound if the bound for each parameter is the same
        bound = np.tile(bound, (num_params, 1))
    elif len(bound) != num_params:
        error = True
        message = 'len(best_fit) and len(bound) should be the same'

    try:
        dt = kwargs['dt']
    except:
        dt = 0.1
    # Setup dt
    if np.ndim(dt)==0:
        dt = np.repeat(dt, num_params)
    elif len(dt) != num_params:
        error = True
        message = 'len(best_fit) and len(dt) should be the same'

    try:
        true_values = kwargs['true_values']
    except:
        true_values = model(best_fit)

    try:
        std_values = kwargs['std_values']
        # Set the standard deviation
        if std_values==0:
            std_values = 0.1 * true_values
        elif np.ndim(std_values)>0 and len(std_values)!=len(true_values):
            error = True
            message = "std_values and true_values should have the same size"
    except:
        std_values = 1

    try:
        points = kwargs['points']
    except:
        points = 0

    try:
        fixed_initial_guess = kwargs['fixed_initial_guess']
        if np.ndim(fixed_initial_guess)==2:
            if np.shape(fixed_initial_guess)[0]==points:
                fixed_initial_guess = np.tile(fixed_initial_guess, (num_params, 1, 1))
            else:
                error = True
                message = "number of rows and number of points should be the same"
    except:
        fixed_initial_guess = np.tile([], (num_params, 1))
    
    try:
        threads = kwargs['threads']
    except:
        threads = 1

    if error:
        raise ValueError(message)

    pool = mp.Pool(threads)
    results = pool.starmap(likelihood_wrapper,
                           [(model, best_fit, i,
                             bound[i], dt[i], true_values,
                             std_values,
                             points, fixed_initial_guess[i])
                            for i in np.arange(num_params)])

    pool.close()
    sys.stdout.flush()
