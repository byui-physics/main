#Notes to user: to get desired calculations, the frequency, step size of
#calculations, file_type, and prefix must be updated manually.

import numpy as np
import pylab
from orca_interface import ORCA
import toml
from julia import Models, Base
import sys
sys.path.append("../")
sys.path.append("../../")
sys.path.append("../../../")
import os
import matplotlib.pyplot as plt

new_file_name = "jacobians_58_no_correlation/"
new_file_name_pure_Jacobians = "jacobians/"

if not os.path.exists(new_file_name_pure_Jacobians):
    os.mkdir(new_file_name_pure_Jacobians)
    print("New directory for pure Jacobians created.")
if not os.path.exists(new_file_name):
    os.mkdir(new_file_name)
    print("New directory created for no correlation between 5,8.")


freq_dropped = [] #contains frequency at which singular values dropped
threshold = 10e-6
parameters_dropped = []

mask = np.ones(11, dtype = np.bool)
 
#Check if jacobians created, create modified ones, begin singular value
#decomposition and sv drop off calculation

#Parameters to change manually
frequency = 64
layer_thickness = 35
environment_type = "sand"
file_type = "{0}_iso".format(enviroment_type)
prefix ="j_{0}".format(environment_type)

print("Starting frequency of run: {:.4f}  Hz".format(frequency))
print("For file type: ", file_type)

for frequency in np.logspace(6,8,100,base=2):
    
    exists_original = os.path.isfile("{0}{1}_{3}m_{2:.4f}.txt".format(new_file_name_pure_Jacobians, prefix, frequency, layer_thickness))
    if not exists_original:
        print("Jacobian has not been calculated. Run \"CalculateJacobians\" to create them.")

    #double-check if new files  exists
    exists2 = os.path.isfile("{0}{1}_{2:.4f}.txt".format(new_file_name_pure_Jacobians, prefix, frequency))
    
    if exists2:
       #calculate jacobian, svd, parameters to drop
       j= np.loadtxt("{0}{1}_{2:.4f}.txt".format(new_file_name_pure_Jacobians, prefix, frequency))
        
       u, s, vh = np.linalg.svd(j[:,mask])
    
       if s[-1] < threshold:
        #collect dropped paraemters, note still valid paraemters,
        #note frequencies of occurance
           parameters_dropped.append(np.array(range(11))[mask][np.abs(vh[-1])> 0.7])
           mask[mask] = np.abs(vh[-1]) < 0.7
           freq_dropped.append(frequency)
    
#post-loop: print dropped paraemters
print("---End results---")
print("Dropped parameters: ", np.array(range(len(mask)))[mask==False])
print("Frequencies of drops: ", freq_dropped)
print("Order of dropped parameters: ", parameters_dropped)
