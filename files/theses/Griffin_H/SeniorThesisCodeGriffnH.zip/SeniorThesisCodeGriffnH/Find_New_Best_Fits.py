"""
7/16/2020

Algorithim created to find the new best fits for each reduction of the 
11-parameter transmission
loss model.
"""

#imports
import sys
import os
sys.path.append("./")
from scipy.optimize import fmin
from orca_interface import ORCA
import numpy as np
from Environments import Environment #varies for each model being tested
import time
from ProxyNameConverter import ProxyNameConverter

################################################################################
#Set up time
################################################################################
start = time.time()


################################################################################
# Setting up environment for tested parameter model
################################################################################
##NOTE: if these variables are changed, update them in the definition for Cost
#as well so that the data is consistent
zmin = 10
zmax = 74
zstep = 1
zr = np.linspace(zmin, zmax, 256)
r = [9]

frequency = 100
file_type = "mud_iso"
layer_thickness = 35
file_path = "./svp_toml/iso_{0}m/".format(layer_thickness) #locates toml files
data_save_path = "data/data_ytrue_11_Params/" #locate 11 parameter original data

#set up for model being tested
env = Environment(file_path, file_type, frequency, zr, r, rmin = 1.5)

################################################################################
# Calculate the current data for the model
################################################################################

#prepare to load data for xi:

#Buildng load name
#instantiate ProxyNameConverter.py instance
proxyConv = ProxyNameConverter(file_type) #dummy variable to initiate
load_frequency = proxyConv.basicFloatConversion(frequency)

#case if 11 parameter model used; else adjust the names for the lesser parameter model.
#########VARIABLES TO CHANGE EACH RUN
parameter11_values_case = True
parameters_in_reduced_model_to_extract_from = 6
paramsRemoved = [5] #index of parameter to removed

if parameter11_values_case == True:
    print("11 parameter original data called. Processing...")
    param_values_save_path = "data/param_values_11_Params/"

    param_values_load_name = "{0}param_values_11_Params_Env_{1}_{2}Hz_{3}m.txt".format(param_values_save_path,file_type, load_frequency, layer_thickness)

else:
    print("Some parameter values for models less than 11 called. Processing...")
    param_values_load_name = "data/calculated_best_fits/best_fit_params_{0}_model_{1}_{2}Hz_{3}m.txt".format(parameters_in_reduced_model_to_extract_from,
                            file_type, load_frequency, layer_thickness)

print("Loading parameter values from ", param_values_load_name)
param_file_check = os.path.exists(param_values_load_name)

if param_file_check == True:

    xTotal = np.loadtxt(param_values_load_name) 
    print("xTotal: ", xTotal)

    xGivenModel = env.x_current()
    print("X if in given model: ", xGivenModel)

    if parameter11_values_case == True: 
        print("Parameters from 11 parameter model called. Check in code that correct parameters selected to remove from model.")
    else:
        print("Parameters from {0} paramter model called. Check in code that correct parameters selected to remove from model.")
    
    print("Parameters getting removed from list: ", paramsRemoved)

    x = np.delete(xTotal, paramsRemoved)
    xi = x
    print("xi: ", xi)
    
#default case set to run program without error
else:
    x = env.x_current()
    xi = x
    print("Error: could not find file to call parameters from. Defaulting to current model's parameters. Results may be erroneous.")

ytrueCurrentModel = env.y(x) #data values

yi= ytrueCurrentModel

#print("x: Our initial guess'/'default values: ", xi)

################################################################################
#Upload data form 11 parameter model
################################################################################
#Load ytrue from 11 parameter model---
#calculated in Data_Generator_11_Param_Model.py


ytrue11_load_name = "{0}ytrueData_11_Params_Env_{1}_{2}Hz_{3}m.txt".format(
    data_save_path, file_type, load_frequency, layer_thickness)
print("Loading ytrue 11 data from file: ", ytrue11_load_name)
ytrue11Params = np.loadtxt(ytrue11_load_name)

################################################################################
#Set up defintion for cost
################################################################################

"""
Function called cost
"""
def Cost(x): #y = data= predictions of full model (11 parameter model)

    ycurrentmodel = env.y(x)
    calculatedCost = sum((ytrue11Params -ycurrentmodel)**2)/2 #data
                                      #- of reduced model squared and summed
    #print("Cost = %.2e" %calculatedCost)
    return calculatedCost


################################################################################
#Calculate the Cost and find the new fmin
################################################################################

print("Shape: ", np.shape(yi))
print("Type: ", type(yi))
resultCost = Cost(xi)
print("When Cost is just called with xi: ")
print(resultCost)
print("Shape of resultCost: ", np.shape(resultCost))
print("Calculating cost values...")
result, fopt, iter, funcalls, warnflag = fmin(Cost, xi,
                                              full_output = 1,
                                              #xtol = 1e-1,
                                              #ftol = 1e-1
                                              #maxiter = 3
                                              )

print("Cost at fit y11: %.2e" %(Cost(result)))
print("xi: ", xi)
print("Result: ", result)
print("Change in data values: ", result - xi)

#export options result for future use options

#ask user if saving file wanted
saveFileQuery = input("Save this new best fit/result? <y>\" yes\"; any other key, \"no\"   ")
print(saveFileQuery)

#directory to save result
new_best_fit_directory = "data/calculated_best_fits/"

#check if directory exists:
NBF_directory_check = os.path.isdir(new_best_fit_directory)

result_size = np.size(result)


NBF_save_name = "{0}best_fit_params_{1}_model_{2}_{3}Hz_{4}m.txt".format(new_best_fit_directory, result_size, file_type, load_frequency, layer_thickness)

print("Result will be saved as ", NBF_save_name)


if saveFileQuery == "y" and NBF_directory_check == True:
    np.savetxt(NBF_save_name, result)
    print("New best fit parameters saved successfully.")
if NBF_directory_check == False:
    print("File directory does not exist. Best fit values not saved. Update directory path.")
if saveFileQuery != "y":
    print("Data not saved.")





