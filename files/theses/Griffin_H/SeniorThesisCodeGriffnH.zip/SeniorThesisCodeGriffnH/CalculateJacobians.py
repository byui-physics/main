
import numpy as np
from orca_interface import ORCA
import toml
import sys
import os

sys.path.append("./")
from Environments import Environment

file_path = "./svp_toml/iso_35m/"
file_type = "gravel_iso"


zmin = 10
zmax = 74
zstep = 1
zr = np.linspace(zmin, zmax, 256)

r = [9]

#make sure jacobians file exists
jacobian_file = "jacobians/"
if not os.path.exists(jacobian_file):
    os.mkdir(jacobian_file)
    print("New directory created.")

frequency = 64
prefix = "j_gravel"
for frequency in np.logspace(6, 8,100, base = 2):
# for frequency in [64]:
    #check if file exists
    if not os.path.exists("{0}{1}_{2:.4f}.txt".format(jacobian_file, prefix, frequency)):
          
        env = Environment(file_path, file_type, frequency, zr, r)
        env.orca.opt.iikpl = 2  # originally 1
        env.orca.opt.db_cut = 120
        env.orca.opt.phfac = 8
    
        x = env.x_current()
        print("Evaluating f = %.4f" %frequency)
        j = env.jacobian(x)

        np.savetxt("{0}{1}_{2:.4f}.txt".format(jacobian_file, prefix, frequency),j)
    else:
        print("Jacobian already calculated.")
